<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Anti Theft Helper</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <script> 
            $(function(){
              $("#header").load("header.html"); 
              //$("#footer").load("footer.html"); 
            });
        </script> 
    </head>
<body>
    <div id="header"></div>
<?php
$a9=$_POST['name'];
$b9=$_POST['pass'];
$sql1="INSERT into users values('$a9','$b9','0')";
$result1= mysqli_query(mysqli_connect("localhost","root","","test_db1"), $sql1);
echo "<center><h1>Your Account Has Been successfully created.</h1></center>";
echo "<center><b><a href='login.php'class='btn'>Go To SignIN page</a></b></center>";
?></body></html>