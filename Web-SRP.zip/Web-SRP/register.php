<!DOCTYPE html>
<html>
    <html leng="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Anti Theft Helper</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
            <script> 
            $(function(){
              $("#header1").load("header.html"); 
              //$("#footer").load("footer.html"); 
            });
            window.onload = function() {
            document.getElementById("music").play();
            }
        </script> 
        <style>
            .container1 {
            max-width: 500px;
            margin: 50px auto;
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .heading {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        .error, .success {
            text-align: center;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .card-details {
            margin-bottom: 20px;
        }

        .card-box {
            margin-bottom: 15px;
        }

        .details {
            font-size: 18px;
            color: #555;
        }

        input[type="text"], input[type="password"], input[type="phone"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .gender {
            margin-bottom: 20px;
        }

        .gendername {
            font-size: 18px;
            color: #555;
        }

        .category {
            margin-top: 10px;
        }

        .button {
            text-align: center;
        }

        input[type="button"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="button"]:hover {
            background-color: #0056b3;
        }

        .login {
            text-align: center;
            font-size: 16px;
            margin-top: 20px;
        }

        .login a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .login a:hover {
            color: #0056b3;
        }
            </style>
    </head>
        <body style='background-color:#f6f9ff'>
        <div id="header1"></div>
        <audio id="music" src="registration.mp3"></audio>
        <div class="container1">
    <div class="heading">Registration</div>
    
    <?php if (isset($_GET['error'])) { ?>
        <p class="error"><b><?php echo $_GET['error']; ?></b></p>
    <?php } ?>

    <?php if (isset($_GET['success'])) { ?>
        <p class="success"><b><?php echo $_GET['success']; ?></b></p>
    <?php } ?> 

    <form action="signup-check.php" method="post" id="fm">
        <div class="card-details">
            <div class="card-box">
                <span class="details">UserName</span>
                <input type="text" name="name" id='name' placeholder="Enter your name" required>
            </div>
            <div class="card-box">
                <span class="details">Phone Number</span>
                <input type="phone" name="phone" id='phone' placeholder="Phone Number" maxlength="10" minlength="10">
            </div>
            <div class="card-box">
                <span class="details">Password</span>
                <input type="password" name="pass" id="psw" placeholder="Enter your password">
            </div>
            <div class="card-box">
                <span class="details">Confirm Password</span>
                <input type="password" name="cpass" id="cnfrmpsw" placeholder="Confirm password">
                <p id="passcpass"></p>
            </div>
        </div>
        <div class="button">
            <input type="button" value="Register" onclick='myfun()'>
        </div>
    </form>

    <div class="login">Already Registered? <a href="login.php">Login here</a></div>
</div>
<script> function myfun(){ 
var a4=document.getElementById('name').value;
var a2=document.getElementById('phone').value;
var a1=document.getElementById('psw').value;
var a5=document.getElementById('cnfrmpsw').value;
if(a4=='' || a4==null){
window.alert('Enter Name');}
else if((Number.isInteger(parseInt(a2)))==false || a2.length!=10)
{
window.alert('Mobile Number should contain only numbers and should have 10 numbers');}
else if(a1.length<8)
{
window.alert("Password should contain eight characters");
}
else if(a1!=a5)
{
window.alert("Password and Confirm password doesn't match!");
}
else{
document.getElementById('fm').submit();
}
}
</script>
       </body>
</html>