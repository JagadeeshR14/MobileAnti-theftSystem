<!DOCTYPE html>
<html>
    <html leng="en">
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" href="login.css">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Anti Theft Helper</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
            <script> 
            $(function(){
              $("#header").load("header.html"); 
              //$("#footer").load("footer.html"); 
            });
            window.onload = function() {
            document.getElementById("music").play();
            }
        </script> 
    </head>
        <body>
        <div id="header"></div>
        <audio id="music" src="login.mp3"></audio>
            <section>
                <div class="form-container">
                    <h1>Login Form</h1>
                    <form action="check2.php" method="post">
                    <div class="control">
                    <?php if (isset($_GET['error'])) { ?>
                            <p class="error" style="color:red;"><?php echo $_GET['error']; ?></p>
                        <?php } ?>   
                        </div>
                        
                        <div class="control">
                            <br><label for ="username">Name</label>
                            <input placeholder="Username" type="text" name="username" id="username">
                        </div>
                        <div class="control">
                            <label for="psw">Password</label>
                            <input placeholder="Password"type="password" name="psw" id="psw">
                        </div>
                        <span><input type="checkbox"> Remember me</span>
                        <div class="control">
                            <input type="submit" value="Login" >
                        </div>
                    </form>
                    <div class="link">
                        <a href="#">Forgot Password?</a>
                    </div><br>
					  <center><div >Don't have an account?
						  <a href='register.php' style='text-decoration:none'>Signup</a></div></center>
                    
                </div>
            </section>
        </body>
</html>