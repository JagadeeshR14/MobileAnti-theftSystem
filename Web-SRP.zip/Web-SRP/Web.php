<!DOCTYPE html>
<html>
<head>
    <title>Mobile Phone Details</title>
	<link rel="stylesheet" type="text/css" href="Design.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function(){
        $("#header").load("header.html"); 
        //$("#footer").load("footer.html"); 
    });
    window.onload = function() {
    document.getElementById("music").play();
    }
    </script>
</head>
<body>
    <div id="header"></div>
    <audio id="music" src="mobile phone.mp3"></audio>
    
    <h2>Select a Mobile Phone</h2>
    <form method="post" action="">
        <label for="brand">Select Brand:</label>
        <select id="brand" name="brand">
			  <option value="" disabled selected>Select Brand</option>
            <option value="Samsung">Samsung</option>
            <option value="Apple">Apple</option>
            <option value="Google">Google</option>
            <option value="Oneplus">Oneplus</option>
            <option value="Vivo">Vivo</option>
            <option value="Nothing">Nothing</option>
            <option value="Xiaomi">Xiaomi</option>
        </select><br><br>


        <label for="model">Select Model:</label>
        <select id="model" name="model">
				<option value="" disabled selected>Select Model</option>
            <!-- Options for Samsung phones -->
            <optgroup label="Samsung">
                <option value="Galaxy S20">Galaxy S20</option>
                <option value="Galaxy S21">Galaxy S21</option>
                <option value="Galaxy S22">Galaxy S22</option>
                <option value="Galaxy S22 Ultra">Galaxy S22 Ultra</option>
                <option value="Galaxy S23">Galaxy S23</option>
                <option value="Galaxy S23 Ultra">Galaxy S23 Ultra</option>
                <option value="Galaxy S24">Galaxy S24</option>
                <option value="Galaxy S24 Ultra">Galaxy S24 Ultra</option>
                <option value="Galaxy Z Fold 3">Galaxy Z Fold 3</option>
                <option value="Galaxy Z Fold 4">Galaxy Z Fold 4</option>
            </optgroup>


            <!-- Options for Apple phones -->
            <optgroup label="Apple">
                <option value="iPhone SE">iPhone SE</option>
                <option value="iPhone 11">iPhone 11</option>
                <option value="iPhone 11 Pro">iPhone 11 Pro</option>
                <option value="iPhone 12">iPhone 12</option>
                <option value="iPhone 12 Pro">iPhone 12 Pro</option>
                <option value="iPhone 13">iPhone 13</option>
                <option value="iPhone 13 Pro">iPhone 13 Pro</option>
                <option value="iPhone 14">iPhone 14</option>
                <option value="iPhone 14 Pro">iPhone 14 Pro</option>
                <option value="iPhone 15">iPhone 15</option>
                <option value="iPhone 15 Pro">iPhone 15 Pro</option>
            </optgroup>


            <!-- Options for Google phones -->
            <optgroup label="Google">
                <option value="Pixel 6">Pixel 6</option>
                <option value="Pixel 6 Pro">Pixel 6 Pro</option>
                <option value="Pixel 7">Pixel 7</option>
                <option value="Pixel 7 Pro">Pixel 7 Pro</option>
                <option value="Pixel 8">Pixel 8</option>
                <option value="Pixel 8 Pro">Pixel 8 Pro</option>
            </optgroup>


            <!-- Options for Oneplus phones -->
            <optgroup label="Oneplus">
                <option value="9">9</option>
                <option value="9 Pro">9 Pro</option>
                <option value="10R">10</option>
                <option value="10 Pro">10 pro</option>
                <option value="11">11</option>
                <option value="11R">11R</option>
                <option value="12">12</option>
                <option value="12R">12R</option>
            </optgroup>


            <!-- Options for Vivo phones -->
            <optgroup label="Vivo">
                <option value="V29">V29</option>
                <option value="V29 Pro">V29 Pro</option>
                <option value="V30">V30</option>
                <option value="V30 Pro">V30 Pro</option>
                <option value="X80 Pro">X80 Pro Plus</option>
                <option value="X90">X90</option>
                <option value="X90 Pro">X90 Pro</option>
                <option value="X100">X100</option>
                <option value="X100 Pro">X100 Pro</option>
            </optgroup>


            <!-- Options for Nothing phones -->
            <optgroup label="Nothing">
                <option value="Phone 1">Phone 1</option>
                <option value="Phone 2">Phone 2</option>
                <option value="Phone 2a">Phone 2a</option>
            </optgroup>


            <!-- Options for Xiaomi phones -->
            <optgroup label="Xiaomi">
                <option value="12">12</option>
                <option value="12 Pro">12 Pro</option>
                <option value="13">13</option>
                <option value="13 Pro">13 Pro</option>
                <option value="14">14</option>
                <option value="14 Pro">14 Pro</option>
                <option value="Redmi Note 12">Redmi Note 12</option>
                <option value="Redmi Note 12 Pro">Redmi Note 12 Pro</option>
                <option value="Redmi Note 13">Redmi Note 13</option>
                <option value="Redmi Note 13 Pro">Redmi Note 13 Pro</option>
            </optgroup>


            <!-- Add options for other brands -->
        </select><br><br>

        <input type="submit" name="submit" value="Get Details">
    </form>

    <?php
    // Handle form submission
    if(isset($_POST['submit'])) {
        $brand = $_POST['brand'];
        $model = $_POST['model'];

        // Simulated database query to fetch details
        $details = getPhoneDetails($brand, $model);

        // Display details
        echo "<h2>Details of $model ($brand)</h2>";
        echo "<textarea rows='10' cols='30'>$details</textarea>";
    }

    // Function to simulate database query (replace with actual database query)
    function getPhoneDetails($brand, $model) {
        // Simulated details
        $details = "Brand: $brand\n";
        $details .= "Model: $model\n";

        // Simulated specifications
        $details .= "Specifications:\n";
        if($brand === "Samsung") {
            if($model === "Galaxy S20") {
                $details .= "- Display: 15.71 cm (6.2 inch) Full HD+ Display\n";
                $details .= "- Camera: 12MP + 10MP | 8 MP Front Camera\n";
                $details .= "- RAM: 8 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4000 mAh\n";
                $details .= "- Processor: Exynos 990\n";
                echo '<img src="sams20.jpeg" alt="Samsung Galaxy S20">';

            }
            elseif($model === "Galaxy S21") {
                $details .= "- Display: 16.26 cm (6.4 inch) Full HD+ Display\n";
                $details .= "- Camera: 12MP + 12MP + 8MP (OIS) | 32MP Front Camera\n";
                $details .= "- RAM: 8 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4500 mAh\n";
                $details .= "- Processor: Snapdragon 888\n";
                echo '<img src="sams21.jpeg" alt="Samsung Galaxy S21">';
            } 
            elseif($model === "Galaxy S22") {
                $details .= "- Display: 17.27 cm (6.8 inch) Display\n";
                $details .= "- Camera: 50MP + 12MP + 10MP | 10MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 1\n";
                echo '<img src="sams22.jpeg" alt="Samsung Galaxy S22">';
            }  
            elseif($model === "Galaxy S22 Ultra") {
                $details .= "- Display: 15.49 cm (6.1 inch) Full HD+ Display\n";
                $details .= "- Camera: 108MP Rear Camera | 40MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 1\n";
                echo '<img src="sams22ultra.jpeg" alt="Samsung Galaxy S22 Ultra">';
            }
            elseif($model === "Galaxy S23") {
                $details .= "- Display: 15.49 cm (6.1 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 10MP + 12MP | 12MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3900 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 2\n";
                echo '<img src="sams23.jpeg" alt="Samsung Galaxy S23">';
            } 
            elseif($model === "Galaxy S23 Ultra") {
                $details .= "- Display: 17.27 cm (6.8 inch) Quad HD+ Display\n";
                $details .= "- Camera: 200MP + 10MP + 12MP + 10MP | 12MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 2\n";
                echo '<img src="sams23ultra.jpeg" alt="Samsung Galaxy S23 Ultra">';
            } 
            elseif($model === "Galaxy S24") {
                $details .= "- Display: 15.49 cm (6.1 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP + 10MP | 12MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3900 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 3\n";
                echo '<img src="sams24.jpeg" alt="Samsung Galaxy S24">';
            }
            elseif($model === "Galaxy S24 Ultra") {
                $details .= "- Display: 17.27 cm (6.8 inch) Quad HD+ Display\n";
                $details .= "- Camera: 200MP + 10MP + 12MP + 10MP | 12MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 3\n";
                echo '<img src="sams24ultra.jpeg" alt="Samsung Galaxy S24 Ultra">';
            } 
            elseif($model === "Galaxy Z Fold 3") {
                $details .= "- Display: 19.3 cm (7.6 inch) QXGA+ Display\n";
                $details .= "- Camera: 12MP + 12MP + 12MP | 10MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4400 mAh\n";
                $details .= "- Processor: Snapdragon 888\n";
                echo '<img src="samszfold3.jpeg" alt="Samsung Galaxy ZFold3">';
            } 
            elseif($model === "Galaxy Z Fold 4 ") {
                $details .= "- Display: 15.49 cm (6.1 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP + 10MP | 10MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4400 mAh\n";
                $details .= "- Processor: Snapdragon 8+ Gen 1\n";
                echo '<img src="samszfold4.jpeg" alt="Samsung Galaxy ZFold4">';
            } 

        } 


            elseif($brand === "Apple") {
            if($model === "iPhone SE") {
                $details .= "- Display: 11.94 cm (4.7 inch) Retina HD Display\n";
                $details .= "- Camera: 12MP Rear Camera | 7MP Front Camera\n";
                $details .= "- Storage: 64/128 GB\n";
                $details .= "- Battery: 3000 mAh\n";
                $details .= "- Processor: A15 Bionic Chip\n";
                echo '<img src="ipse.jpeg" alt="Apple iPhone SE">';
                
            } 
            elseif($model === "iPhone 11") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 64/128/256 GB\n";
                $details .= "- Battery: 3000 mAh\n";
                $details .= "- Processor: A13 Bionic Chip\n";
                echo '<img src="ip11.jpeg" alt="Apple iPhone 11">';
            } 
            elseif($model === "iPhone 11 Pro") {
                $details .= "- Display: 14.73 cm (5.8 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256 GB\n";
                $details .= "- Battery: 3000 mAh\n";
                $details .= "- Processor: A13 Bionic Chip\n";
                echo '<img src="ip11pro.jpeg" alt="Apple iPhone 11 Pro">';
            }  
            elseif($model === "iPhone 12") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 64/128/256 GB\n";
                $details .= "- Battery: 3300 mAh\n";
                $details .= "- Processor: A14 Bionic Chip with Next Generation Neural Engine\n";
                echo '<img src="ip12.jpeg" alt="Apple iPhone 12">';
            }
            elseif($model === "iPhone 12 Pro") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3500 mAh\n";
                $details .= "- Processor: A14 Bionic Chip with Next Generation Neural Engine\n";
                echo '<img src="ip12pro.jpeg" alt="Apple iPhone 12 Pro">';
            } 
            elseif($model === "iPhone 13") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3400 mAh\n";
                $details .= "- Processor: A15 Bionic Chip\n";
                echo '<img src="ip13.jpeg" alt="Apple iPhone 13">';
            } 
            elseif($model === "iPhone 13 Pro") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3700 mAh\n";
                $details .= "- Processor: A15 Bionic Chip\n";
                echo '<img src="ip13pro.jpeg" alt="Apple iPhone 13 Pro">';
            } 
            elseif($model === "iPhone 14") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3500 mAh\n";
                $details .= "- Processor: A15 Bionic Chip\n";
                echo '<img src="ip14.jpeg" alt="Apple iPhone 14 Pro">';
            } 
            elseif($model === "iPhone 14 Pro") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 48MP + 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 3800 mAh\n";
                $details .= "- Processor: A16 Bionic Chip\n";
                echo '<img src="ip14pro.jpeg" alt="Apple iPhone 14 Pro">';
            } 
            elseif($model === "iPhone 15") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 48MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4000 mAh\n";
                $details .= "- Processor: A16 Bionic Chip,\n";
                echo '<img src="ip15.jpeg" alt="Apple iPhone 15">';
            } 
            elseif($model === "iPhone 15 Pro") {
                $details .= "- Display: 15.49 cm (6.1 inch) Super Retina XDR Display\n";
                $details .= "- Camera: 48MP + 12MP + 12MP | 12MP Front Camera\n";
                $details .= "- Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4200 mAh\n";
                $details .= "- Processor: A17 Pro Chip\n";
                echo '<img src="ip15pro.jpeg" alt="Apple iPhone 15 Pro">';
            }

        }


            elseif($brand === "Google") {
            if($model === "Pixel 6") {
                $details .= "- Display: 15.6 cm (6.14 inch) Full HD+ Display\n";
                $details .= "- Camera: 12.2MP + 12MP | 8MP Front Camera\n";
                $details .= "- RAM: 6/8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4410 mAh\n";
                $details .= "- Processor: Google Tensor\n";
                echo '<img src="g6.jpeg" alt="Google Pixel 6">';
            }
            elseif($model === "Pixel 7") {
                $details .= "- Display: 16.0 cm (6.3 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP | 10.8MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4270 mAh\n";
                $details .= "- Processor: Google Tensor G2 \n";
                echo '<img src="g7.jpeg" alt="Google Pixel 7">';
            } 
            elseif($model === "Pixel 7 Pro") {
                $details .= "- Display: 17.02 cm (6.7 inch) Quad HD+ Display\n";
                $details .= "- Camera: 50MP + 48MP + 12MP | 10.8MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4926 mAh\n";
                $details .= "- Processor: Google Tensor G2\n";
                echo '<img src="g7pro.jpeg" alt="Google Pixel 7 Pro">';
            } 
            elseif($model === "Pixel 8") {
                $details .= "- Display: 15.75 cm (6.2 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP | 10.5MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4575 mAh\n";
                $details .= "- Processor: Google Tensor G3\n";
                echo '<img src="g8.jpeg" alt="Google Pixel 8">';
            } 
            elseif($model === "Pixel 8 Pro") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ AMOLED Display\n";
                $details .= "- Camera: 50MP + 48MP + 48MP | 10.5MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5050 mAh\n";
                $details .= "- Processor: Google Tensor G3\n";
                echo '<img src="g8pro.jpeg" alt="Google Pixel 8 Pro">';
            }  
		 }



            elseif($brand === "Oneplus") {
            if($model === "9") {
                $details .= "- Display: 16.64 cm (6.55 inch) Full HD+ Display\n";
                $details .= "- 48MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4500 mAh\n";
                $details .= "- Processor: Snapdragon 888\n";
                echo '<img src="1+9.jpeg" alt="Oneplus 9">';
            }
            elseif($model === "9 Pro") {
                $details .= "- Display: 16.64 cm (6.55 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4500 mAh\n";
                $details .= "- Processor: Snapdragon 888\n";
                echo '<img src="1+9pro.jpeg" alt="Oneplus 9 Pro">';
            } 
            elseif($model === "10") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 8MP + 2MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 8100-MAX\n";
                echo '<img src="1+10.jpeg" alt="Oneplus 10">';
            } 
            elseif($model === "10 Pro") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 888+\n";
                echo '<img src="1+10pro.jpeg" alt="Oneplus 10 Pro">';
            } 
            elseif($model === "11") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 48MP + 8MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 gen 2\n";
                echo '<img src="1+11.jpeg" alt="Oneplus 11">';
            } 
            elseif($model === "11R") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 48MP + 8MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8+ gen 1\n";
                echo '<img src="1+11r.jpeg" alt="Oneplus 11R">';
            } 
            elseif($model === "12") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 64MP + 48MP + 8MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 256/512 GB\n";
                $details .= "- Battery: 5400 mAh\n";
                $details .= "- Processor: Snapdragon 8 gen 3\n";
                echo '<img src="1+12.jpeg" alt="Oneplus 12">';
            } 
            elseif($model === "12R") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 64MP + 8MP + 2MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 256/512 GB\n";
                $details .= "- Battery: 5160 mAh\n";
                $details .= "- Processor: Snapdragon 8 gen 2\n";
                echo '<img src="1+12r.jpeg" alt="Oneplus 12R">';
            }  
		 }



            elseif($brand === "Vivo") {
            if($model === "V29") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ AMOLED Display\n";
                $details .= "- 50MP + 8MP + 2MP | 50MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4600 mAh\n";
                $details .= "- Processor: Snapdragon 778G\n";
                echo '<img src="v29.jpeg" alt="Vivo V29">';
            }
            elseif($model === "V29 Pro") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ AMOLED Display\n";
                $details .= "- Camera: 50MP + 12MP + 8MP | 50MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4600 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 8200\n";
                echo '<img src="v29pro.jpeg" alt="Vivo V29 Pro">';
            } 
            elseif($model === "V30") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP | 50MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 7 Gen 3 \n";
                echo '<img src="v30.jpeg" alt="Vivo V30">';
            } 
            elseif($model === "V30 Pro") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 50MP | 50MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 8200\n";
                echo '<img src="v30pro.jpeg" alt="Vivo V30 Pro">';
            } 
            elseif($model === "X80 Pro") {
                $details .= "- Display: 17.22 cm (6.78 inch) Quad HD Display\n";
                $details .= "- Camera: 50MP + 48MP + 12MP + 8MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4700 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 1\n";
                echo '<img src="x80pro.jpeg" alt="Vivo X80 Pro">';
            } 
            elseif($model === "X90") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 12MP + 12MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4810 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 9200\n";
                echo '<img src="x90.jpeg" alt="Vivo X90">';
            } 
            elseif($model === "X90 Pro") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 12MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12/16 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4870 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 9200\n";
                echo '<img src="x90pro.jpeg" alt="Vivo X90 Pro">';
            }  
            elseif($model === "X100") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 64MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12/16 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 9300\n";
                echo '<img src="x100.jpeg" alt="Vivo X100">';
            } 
            elseif($model === "X100 Pro") {
                $details .= "- Display: 17.22 cm (6.78 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 50MP | 32MP Front Camera\n";
                $details .= "- RAM: 12/16 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 9300\n";
                echo '<img src="x100pro.jpeg" alt="Vivo X100 Pro">';
            } 
		} 


            elseif($brand === "Nothing") {
            if($model === "Phone 1") {
                $details .= "- Display: 16.64 cm (6.55 inch) Full HD+ Display\n";
                $details .= "- 50MP + 50MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4500 mAh\n";
                $details .= "- Processor: Snapdragon 778G+\n";
                echo '<img src="phone1.jpeg" alt="Nothing Phone 1">';
            }
            elseif($model === "Phone 2") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50 MP(OIS) +50MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4700 mAh\n";
                $details .= "- Processor: Snapdragon 8+ Gen 1\n";
                echo '<img src="phone2.jpeg" alt="Nothing Phone 2">';
            } 
            elseif($model === "Phone 2a") {
                $details .= "- Display: 17.02 cm (6.7 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP (OIS) + 50MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 7200 Pro\n";
                echo '<img src="phone2a.jpeg" alt="Nothing Phone 2a">';
            }
		}


            elseif($brand === "Xiaomi") {
            if($model === "12") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Displa\n";
                $details .= "- 50MP + 50MP + 8MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256 GB\n";
                $details .= "- Battery: 4500 mAh\n";
                $details .= "- Processor: Snapdragon 888\n";
                echo '<img src="mi12.jpeg" alt="Xiaomi 12">';
            }
            elseif($model === "12 Pro") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 50MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4600 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 1\n";
                echo '<img src="mi12pro.jpeg" alt="Xiaomi 12 Pro">';
            } 
            elseif($model === "13") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 8MP + 16MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4800 mAh\n";
                $details .= "- Processor: Snapdragon 8+ Gen 1\n";
                echo '<img src="mi13.jpeg" alt="Xiaomi 13 Pro">';
            } 
            elseif($model === "13 Pro") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 64MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 2\n";
                echo '<img src="mi13pro.jpeg" alt="Xiaomi 13 Pro">';
            } 
            elseif($model === "14") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Display\n";
                $details .= "- 50MP + 16MP + 50MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4660 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 3\n";
                echo '<img src="mi14.jpeg" alt="Xiaomi 14">';
            } 
            elseif($model === "14 Pro") {
                $details .= "- Display: 17.09 cm (6.73 inch) Full HD+ Display\n";
                $details .= "- Camera: 50MP + 50MP + 50MP | 32MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 4880 mAh\n";
                $details .= "- Processor: Snapdragon 8 Gen 3\n";
                echo '<img src="mi14pro.jpeg" alt="Xiaomi 14 Pro">';
            } 
            elseif($model === "Redmi Note 12") {
                $details .= "- Display: 16.94 cm (6.67 inch) Full HD+ Super AMOLED Display\n";
                $details .= "- Camera: 50MP + 8MP + 2MP | 13MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Snapdragon 685\n";
                echo '<img src="minote12.jpeg" alt="Redmi Note 12">';
            } 
            elseif($model === "Redmi Note 12 Pro") {
                $details .= "- Display: 16.94 cm (6.67 inch) Full HD+ AMOLED Display\n";
                $details .= "- Camera: 50MP (OIS) + 8MP + 2MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 1080\n";
                echo '<img src="mi12.jpeg" alt="Xiaomi 12">';
            } 
            elseif($model === "Redmi Note 13") {
                $details .= "- Display: 16.94 cm (6.67 inch) Display\n";
                $details .= "- Camera: 108MP + 8MP + 2MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5000 mAh\n";
                $details .= "- Processor: Mediatek Dimensity 6080\n";
                echo '<img src="minote13.jpeg" alt="Redmi Note 13">';
            } 
            elseif($model === "Redmi Note 13 Pro") {
                $details .= "- Display: 16.94 cm (6.67 inch) Display\n";
                $details .= "- Camera: 200MP (OIS) + 8MP + 2MP | 16MP Front Camera\n";
                $details .= "- RAM: 8/12 GB, Storage: 128/256/512 GB\n";
                $details .= "- Battery: 5100 mAh\n";
                $details .= "- Processor: Snapdragon 7s Gen 2 \n";
                echo '<img src="minote13pro.jpeg" alt="Redmi Note 13 Pro">';
            }
		 }
        return $details;
    }
    ?>
</body>
</html>
