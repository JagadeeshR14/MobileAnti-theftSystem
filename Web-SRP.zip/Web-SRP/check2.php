<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap demo</title>
        <link href="https://fonts.cdnfonts.com/css/graphik-trial" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <style>
                .btn{
        display: inline-block;
        padding:.5rem 1rem;
        border:.2rem solid var(--red);
        color:var(--red);
        cursor: pointer;
        font-size: 1rem;
        border-radius: .5rem;
        position: relative;
        overflow: hidden;
        z-index: 0;
        margin-top: 1rem;
        background:#fbeeca;
        }
        .btn:hover
        {
            background:aqua;
        }
          .navbar:hover {
            background-color:#fbeeca !important;
        }
        .navbar-toggler:hover {
            background-color: #fbeeca !important;
            
        }
        .navbar-nav .nav-item .nav-link:hover {
          color:rgb(240, 94, 94) !important;
        }
        .txt{
          font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif ;
          font-size: large;
        }
      </style>
      </head>
<body>
      <nav class="navbar navbar-expand-lg navbar-light txt" style="background-color: #c9cb95;">
        <a class="navbar-brand" href="#"><img src="1.jpg.avif" width="30" height="30" class="d-inline-block align-top" alt="" style="margin-left: 10px;margin-right:10px;">Anti Theft System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
          </ul>
        </div>
        <div>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="#">Register</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>
        </div>
      </nav>
<?php
$a1=mysqli_connect("localhost","root","","test_db1");
if (isset($_POST['username']) && isset($_POST['psw'])) {
	$uname=$_POST['username'];
	$pass=$_POST['psw'];
	if (empty($uname)) {
		header("Location: login.php?error=UserName is required");
	    exit();
	}else if(empty($pass)){
        header("Location: login.php?error=Password is required");
	    exit();
	}
	else{
	$sql2 = "SELECT * FROM users where user_name='$uname'";
	$result2 = mysqli_query($a1,$sql2);
	$row=mysqli_fetch_assoc($result2);
	if($row){
	if($row['user_name']==$uname && $row['password']==$pass){
echo "<center><h1>Your are successfully logged in</h1></center>";
echo "<center><b><a href='home1.html' class='btn'>Go To HomePage</a></b></center>";}
	else{
	header("Location: login.php?error=UserName and Password doesn't match");
	    exit();
}
}}}?>